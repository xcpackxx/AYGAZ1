// JavaScript Kodları Buraya Eklenecek
// Örneğin, bir portföy galerisi veya film önerileri için JavaScript kodları burada olabilir.
// Bu örnekte genel bir şablon sundum, detaylı içerik eklemek size kalmış.
